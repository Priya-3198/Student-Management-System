package com.StudentsManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmSystemApplication.class, args);
	}

}

package com.StudentsManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
